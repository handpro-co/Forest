import Skeleton from "react-loading-skeleton";

const skeletonLoaderCategory = () => {
  return <Skeleton borderRadius={12} count={1} height={60} width={200} />;
};
export default skeletonLoaderCategory;
