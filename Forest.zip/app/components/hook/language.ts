import { atom } from "jotai";

export const translate = atom<string>("mn");
